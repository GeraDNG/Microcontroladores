/*            50Hz        en timer 0
#include <io.h>
void main(){
    DDRD.6=1;  //salida
    TCCR0A=0x42;
    TCCR0B=0x03;
    OCR0A=155;
    while(1){          
    }
}
*/

/*          1600Hz      en timer 0
#include <io.h>
void main(){
    DDRD.6=1;  //salida
    TCCR0A=0x42;
    TCCR0B=0x02;
    OCR0A=38;
    //OCR1AH=311/256; //399>>8
    //OCR1AL=311%256; //399&0xFF
    while(1){          
    }
}
*/    

/*          1600Hz     en timer 1
#include <io.h>
void main(){
    DDRB.1=1;  //salida
    TCCR1A=0x40;
    TCCR1B=0x09;
    OCR1AH=311/256; //399>>8
    OCR1AL=311%256; //399&0xFF
    while(1){          
    }
}
*/

/*        5Hz         en timer 1
#include <io.h>
void main(){
    DDRB.1=1;  //salida
    TCCR1A=0x40;
    TCCR1B=0x0A;
    OCR1AH=12499/256; //399>>8
    OCR1AL=12499%256; //399&0xFF
    while(1){          
    }
}
*/

/*      100Hz           en timer 2
#include <io.h>
void main(){
    DDRB.3=1;  //salida
    TCCR2A=0x42;
    TCCR2B=0x03;
    OCR2A=155;
    while(1){          
    }
}
*/

#include <io.h>
void main(){
    DDRB.3=1;  //salida
    TCCR2A=0x42;
    TCCR2B=0x01;
    OCR2A=249;
    while(1){          
    }
}